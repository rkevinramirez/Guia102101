(function() {
	$(document).on("ready", function() {
    PNotify.prototype.options.styling = "bootstrap3";
	});
})();